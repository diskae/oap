﻿using System;

class Program
{
    static void Main()
    {   
        Console.Write("Введите N: ");
        double N = double.Parse(Console.ReadLine());
        double result = equation(N);
        Console.WriteLine("Результат: " + result);
    }

    static double equation(double N)
    {
        double sum = 0;
        for (double i = N; i >= 1; i--)
        {
            sum = Math.Sqrt(i + sum);
        }
        return N / sum;
    }
}