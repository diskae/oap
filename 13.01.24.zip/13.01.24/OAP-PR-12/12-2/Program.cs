﻿using System;

class Program
{
    static void Main()
    {
        int num = 10;
        text(num);
    }

    static void text(int n)
    {
        if (n == 0)
        {
            Console.WriteLine("И больше лунатиков не стало на луне");
            return;
        }

        Console.WriteLine($"{n} лунатиков жили на луне");
        Console.WriteLine($"{n} лунатиков ворочались во сне");
        Console.WriteLine("Один из лунатиков упал с луны во сне");
        Console.WriteLine($"{n - 1} лунатиков осталось на луне");
        Console.WriteLine();

        text(n - 1);
    }
}