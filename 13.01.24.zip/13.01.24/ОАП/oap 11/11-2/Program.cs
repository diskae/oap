﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using library;

namespace _11_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите размер массива X: ");
            int sizeX = int.Parse(Console.ReadLine());

            double[] X = new double[sizeX];

            for (int i = 0; i < sizeX; i++)
            {
                Console.Write($"Введите элемент массива X [{i+1}]: ");
                X[i] = double.Parse(Console.ReadLine());
            }

            //

            Console.Write("Введите размер массива Y: ");
            int sizeY = int.Parse(Console.ReadLine());

            double[] Y = new double[sizeY];

            for (int i = 0; i < sizeY; i++)
            {
                Console.Write($"Введите элемент массива Y [{i + 1}]: ");
                Y[i] = double.Parse(Console.ReadLine());
            }

            //

            
            Console.WriteLine("Заполненный массив X:");
            findmax.printArray(sizeX, X);

            Console.WriteLine("Заполненный массив Y:");
            findmax.printArray(sizeY, Y);

            //

            double xMax = findmax.findMax(X);
            double yMax = findmax.findMax(Y);

            double z = findmax.equation(xMax, yMax);

            Console.WriteLine($"\nОтвет {z:F2}");
            
        }
    }
}
