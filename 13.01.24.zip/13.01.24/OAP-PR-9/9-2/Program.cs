﻿using System;

class Program
{
    static void Main()
    {
        int M = 6;
        int N = 7;

        int[,] matrix = new int[M, N];
        Random random = new Random();

        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < N; j++)
            {
                matrix[i, j] = random.Next(-20, 20);
            }
        }

        Console.WriteLine("Исходная матрица:");
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < N; j++)
            {
                Console.Write(matrix[i, j] + "\t");
            }
            Console.WriteLine();
        }

        int minChetSumColumn = -1;
        int minChetSum = int.MaxValue;

        for (int j = 0; j < N; j++)
        {
            int chetSum = 0;
            for (int i = 0; i < M; i++)
            {
                if (matrix[i, j] % 2 == 0)
                {
                    chetSum += matrix[i, j];
                }
            }

            if (chetSum < minChetSum)
            {
                minChetSum = chetSum;
                minChetSumColumn = j;
            }
        }

        Console.WriteLine($"Столбец с минимальной суммой всех четных элементов: {minChetSumColumn + 1}, сумма: {minChetSum}");

        for (int i = 0; i < M; i++)
        {
            matrix[i, 4] = 3 * matrix[i, 1];
        }

        Console.WriteLine("Преобразованная матрица:");
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < N; j++)
            {
                Console.Write(matrix[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }
}