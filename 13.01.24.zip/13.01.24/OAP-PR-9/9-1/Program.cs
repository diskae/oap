﻿using System;

class Program
{
    static void Main()
    {
        int[,] matrix = new int[6, 6];
        Random random = new Random();

        for (int i = 0; i < 6; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                matrix[i, j] = random.Next(-20, 20);
            }
        }

        int maxAbsValue = int.MinValue;
        int maxAbsRow = -1;
        int maxAbsCol = -1;

        for (int i = 0; i < 6; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                int absValue = Math.Abs(matrix[i, j]);
                if (absValue > maxAbsValue)
                {
                    maxAbsValue = absValue;
                    maxAbsRow = i;
                    maxAbsCol = j;
                }
            }
        }

        Console.WriteLine($"Наибольший по модулю элемент: {maxAbsValue}, строка: {maxAbsRow}, столбец: {maxAbsCol}");

        int[,] newMatrix = new int[6, 6];
        int row = 0;

        for (int i = 0; i < 6; i++)
        {
            if (i != maxAbsRow)
            {
                for (int j = 0; j < 6; j++)
                {
                    newMatrix[row, j] = matrix[i, j];
                }
                row++;
            }
        }

        int[] array = new int[30];
        int index = 0;

        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                array[index] = newMatrix[i, j]; //индекс массива равен значению двумерного
                index++;
            }
        }

        Console.WriteLine("Одномерный массив:");
        foreach (int elem in array)
        {
            Console.Write(elem + " ");
        }
    }
}