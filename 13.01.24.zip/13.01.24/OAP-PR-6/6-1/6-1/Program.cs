﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("Введите координаты точки. x, затем y:");
        double.TryParse(Console.ReadLine(), out double x);
        double.TryParse(Console.ReadLine(), out double y);

        //a=4x+2 lu
        //b=-4x+2 ru
        //c=4x-2 rd
        //d=-4x-2 ld

        double a,b,c,d;
        a=4*x+2;
        b=-4*x+2;
        c=4*x-2;
        d=-4*x-2;

        if (y < a && y < b && y > c && y > d) {Console.WriteLine("Точка находится внутри области");}
        else if (y == a || y == b || y == c || y == d) {Console.WriteLine("На границе");}
        else {Console.WriteLine("Точка находится вне области");}
    }
}