﻿using System;
using System.Data.Common;
class Program
{
    static void Main(string[]args)
    {
        Console.Write("Введите количество баллов: ");
        int score = int.Parse(Console.ReadLine());
        string res;

        switch (score)
        {
            case int a when a >= 90 && a <= 100:
                res = "Отлично"; break;
            case int a when a >= 70 && a <= 89:
                res = "Хорошо"; break;
            case int a when a >= 50 && a <= 69:
                res = "Удовлетворительно"; break;
            case int a when a <50:
                res = "Неудовлетворительно"; break;
            default:
                res = "Некорректное значение баллов";
                break;
        }

        Console.WriteLine(res);
    }
}