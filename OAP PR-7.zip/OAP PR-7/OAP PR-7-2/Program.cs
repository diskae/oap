﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Введите n, n >= k >= 0:");
        int.TryParse(Console.ReadLine(), out int n);

        Console.WriteLine("Введите k, n >= k >= 0:");
        int.TryParse(Console.ReadLine(), out int k);

        if (n >= k && k >= 0)
        {
            double result = equation(n, k);
            Console.WriteLine($"Результат: {result}");
        }
        else
        {
            Console.WriteLine("Ошибка ввода");
        }
    }

    static double equation(int n, int k)
    {
        double chis = 1;
        for (int i = 0; i < k; i++)
        {
            chis *= (n - i);
        }

        double znam = 1;
        for (int i = 2; i <= k; i++)
        {
            znam *= i;
        }

        return chis / znam;
    }
}
