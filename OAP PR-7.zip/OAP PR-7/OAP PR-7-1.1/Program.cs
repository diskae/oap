﻿using System;

class Program
{
    static void Main()
    {
        while (true)
        {
            Console.Write("Введите число или 'q' для выхода: ");
            string input = Console.ReadLine();

            if (input == "q")
            {
                Console.WriteLine("Выход из программы.");
                break;
            }

            else
            {
                int num = int.Parse(input);
                int min = 9;
                while (num > 0)
                {
                    int d = num % 10;
                    if (d < min)
                    {
                        min = d;
                    }
                    num /=10; //удаляет последнюю цифру числа
                }
                Console.WriteLine($"Минимальная цифра {min}");
            }
        }   
    }
}