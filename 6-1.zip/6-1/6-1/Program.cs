﻿using System;
class Program
{
    static void Main()
    {
        //y=kx+b
        //x|0|0.5| 0|-0.5|
        //y|2| 0 |-2|  0 |

        //{0*k+b=2
        //{0.5*k+b=0
        //0.5*k+2=0 ---> k=-2*2=-4
        //----> y = -4x+2

        Console.WriteLine("Введите координаты точки. x, затем y:");
        double.TryParse(Console.ReadLine(), out double x);
        double.TryParse(Console.ReadLine(), out double y);

        if (-4*x+2 == y) {Console.WriteLine("На границе");}
        else if (-4*x+2 < y) {Console.WriteLine("Вне");}
        else if (-4*x+2 > y) {Console.WriteLine("Внутри");}
    }
}