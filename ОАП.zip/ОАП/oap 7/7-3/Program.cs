﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Заданное значение аргумента x
            double x = 1.0;
            double epsilon = 0.01; // Точность
            double sumNumerator = 0.0; // Для числителя f(x) (sin(x - 0.50))
            double sumDenominator = 0.0; // Для знаменателя f(x) (sin(2x))

            // Числитель (sin(x - 0.50))
            Console.WriteLine("Вычисление числителя sin(x - 0.50):");
            sumNumerator = CalculateTaylorSeries(x - 0.50, epsilon);

            // Знаменатель (sin(2x))
            Console.WriteLine("\nВычисление знаменателя sin(2x):");
            sumDenominator = CalculateTaylorSeries(2 * x, epsilon);

            // Проверка на деление на 0
            if (Math.Abs(sumDenominator) < epsilon)
            {
                Console.WriteLine("\nОшибка: знаменатель слишком мал, деление невозможно.");
            }
            else
            {
                // Значение f(x)
                double fx = sumNumerator / sumDenominator;
                Console.WriteLine($"\nF(x) = {fx:F5}");
            }
        }

        static double CalculateTaylorSeries(double x, double epsilon)
        {
            double term = x; // Первый член ряда
            double sum = 0.0; // Начальная сумма
            int n = 1; // Номер текущей итерации

            Console.WriteLine("№ итерации\tСлагаемое\t\tСумма");

            // Цикл выполняется, пока слагаемое по модулю больше или равно точности
            while (Math.Abs(term) >= epsilon)
            {
                // Добавляем текущее значение `term` к сумме
                sum += term;

                // Выводим текущие данные
                Console.WriteLine($"{n}\t\t{term:F5}\t\t{sum:F5}");

                // Вычисление следующего члена ряда
                term *= -1 * x * x / ((2 * n) * (2 * n + 1));
                n++;

            }
            return sum;
        }
    }
    
}
