﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class findmax
    {
        public static double findMax(double[] array)
        {
            double max = array[0];
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] > max)
                {
                    max = array[i];
                }
            }
            return max;
        }

        public static double equation(double x, double y)
        {
            double chis = x + y;
            double znam = Math.Sqrt(x * y);
            return chis / znam;
        }

        public static double printArray(int size, double[] array)
        {
            for (int i = 0; i < size; i++)
            {
                Console.Write(array[i] + " ");
            }
            Console.WriteLine();
            return 0;
        }
    }
}
