﻿//ax+b=0
//a=max(k^2, l, sqrtM)
//b=max(3^m, l^3, k+l)

using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("Введите k, l, m: ");
        double k,l,m;
        double.TryParse(Console.ReadLine(), out k);
        double.TryParse(Console.ReadLine(), out l);
        double.TryParse(Console.ReadLine(), out m);

        double a0, a1, a2, b0, b1, b2;
        a0 = Math.Pow(k,2);
        a1 = l;
        a2 = Math.Sqrt(m);
        b0 = Math.Pow(3,m);
        b1 = Math.Pow(l,3);
        b2 = k+l;

        double aMax = maxA(a0, a1, a2);
        
        maxA(b0, b1, b2, out double bMax);

        double result = equation(aMax, bMax);

        Console.WriteLine($"a = {aMax}, b = {bMax}, x = -b/a");
        Console.WriteLine($"Результат: {Math.Round(result,2)}");
        Console.ReadKey();
    }

    static double maxA(double a0, double a1, double a2)
    {
        if (a0>a1 || a0>a2) 
        {
            double aMax=a0;
            return aMax;
        }

        else if (a1>a0 || a1>a2)
        {
            double aMax=a1;
            return aMax;
        }

        else
        {
            double aMax=a2;
            return aMax;
        }
    }

    static void maxA(double b0, double b1, double b2, out double bMax)
    {
        if (b0>b1 || b0>b2)
        {
            bMax=b0;
        }

        else if (b1>b0 || b1>b2)
        {
            bMax=b1;
        }

        else
        {
            bMax=b2;
        }
    }

    //перегрузка
    static void maxA(float b0, float b1, float b2, out float bMax)
    {
        if (b0 > b1 || b0 > b2)
        {
            bMax = b0;
        }

        else if (b1 > b0 || b1 > b2)
        {
            bMax = b1;
        }

        else
        {
            bMax = b2;
        }
    }

    static double equation(double aMax, double bMax)
    {
        //ax=-b
        //x = -b/a
        return -bMax/aMax;;
    }
    
}